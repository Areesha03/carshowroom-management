/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package project;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class A_ADDcardetails extends javax.swing.JFrame {

    /**
     * Creates new form A_ADDcardetails
     */
    public A_ADDcardetails() {
        initComponents();
    }

   void Clear(){
        jTextField1.setText("");
     txtCarModel.setText("");
        txtEngine.setText("");
        txtMileage.setText("");
        txtbhp.setText("");
        txtSpeed.setText("");
        txtColour.setText("");
        txtYSC.setText("");
        txtAvg.setText("");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtCarName = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        txtCarModel = new javax.swing.JTextField();
        txtMileage = new javax.swing.JTextField();
        txtEngine = new javax.swing.JTextField();
        CBox = new javax.swing.JComboBox<>();
        txtbhp = new javax.swing.JTextField();
        txtSpeed = new javax.swing.JTextField();
        txtColour = new javax.swing.JTextField();
        txtYSC = new javax.swing.JTextField();
        txtAvg = new javax.swing.JTextField();
        CBoxFuel = new javax.swing.JComboBox<>();
        btnSub = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCarName.setBackground(new java.awt.Color(0, 0, 0,80));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ADD CAR DETAILS");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Car Name");

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Car Model");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Mileage (km/h)");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Engine  (cc)");

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("BHP (Break HoresPower)");

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Transmission");

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Top Speed");

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Colour Available");

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Yearly Service Charge");

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Avg Cost");

        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Fuel Type");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        txtCarModel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCarModelActionPerformed(evt);
            }
        });

        txtMileage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMileageActionPerformed(evt);
            }
        });

        txtEngine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEngineActionPerformed(evt);
            }
        });

        CBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Auto", "Manual" }));
        CBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBoxActionPerformed(evt);
            }
        });

        txtbhp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbhpActionPerformed(evt);
            }
        });

        txtSpeed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSpeedActionPerformed(evt);
            }
        });

        txtColour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtColourActionPerformed(evt);
            }
        });

        txtYSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtYSCActionPerformed(evt);
            }
        });

        txtAvg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAvgActionPerformed(evt);
            }
        });

        CBoxFuel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Petrol", "Diesel", "CNG" }));
        CBoxFuel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBoxFuelActionPerformed(evt);
            }
        });

        btnSub.setText("SUMBIT");
        btnSub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubActionPerformed(evt);
            }
        });

        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout txtCarNameLayout = new javax.swing.GroupLayout(txtCarName);
        txtCarName.setLayout(txtCarNameLayout);
        txtCarNameLayout.setHorizontalGroup(
            txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtCarNameLayout.createSequentialGroup()
                .addGap(197, 197, 197)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(txtCarNameLayout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(btnSub)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnClear)
                        .addGap(76, 76, 76)
                        .addComponent(btnBack)
                        .addGap(182, 182, 182))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, txtCarNameLayout.createSequentialGroup()
                        .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(txtCarNameLayout.createSequentialGroup()
                                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(84, 84, 84)
                                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField1)
                                    .addComponent(txtCarModel)
                                    .addComponent(txtMileage)
                                    .addComponent(txtEngine, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                                    .addComponent(txtbhp, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(txtCarNameLayout.createSequentialGroup()
                                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel12))
                                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(txtCarNameLayout.createSequentialGroup()
                                        .addGap(94, 94, 94)
                                        .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtSpeed)
                                            .addComponent(txtColour)
                                            .addComponent(txtYSC)
                                            .addComponent(CBoxFuel, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(txtCarNameLayout.createSequentialGroup()
                                                .addGap(6, 6, 6)
                                                .addComponent(txtAvg))))
                                    .addGroup(txtCarNameLayout.createSequentialGroup()
                                        .addGap(100, 100, 100)
                                        .addComponent(CBox, 0, 215, Short.MAX_VALUE)))))
                        .addGap(256, 256, 256))))
            .addGroup(txtCarNameLayout.createSequentialGroup()
                .addGap(219, 219, 219)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        txtCarNameLayout.setVerticalGroup(
            txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtCarNameLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCarModel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(15, 15, 15)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMileage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(12, 12, 12)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtEngine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtbhp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSpeed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtColour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtYSC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAvg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CBoxFuel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addGap(21, 21, 21)
                .addGroup(txtCarNameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClear)
                    .addComponent(btnBack)
                    .addComponent(btnSub))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        getContentPane().add(txtCarName, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 880, 580));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/images/car6 (1) (1).jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, -1));

        setSize(new java.awt.Dimension(1114, 741));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtEngineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEngineActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEngineActionPerformed

    private void CBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CBoxActionPerformed

    private void txtbhpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbhpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbhpActionPerformed

    private void txtSpeedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSpeedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSpeedActionPerformed

    private void txtColourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtColourActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtColourActionPerformed

    private void txtYSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtYSCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtYSCActionPerformed

    private void txtAvgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAvgActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAvgActionPerformed

    private void CBoxFuelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBoxFuelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CBoxFuelActionPerformed

    private void btnSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubActionPerformed
        String carname= jTextField1.getText();
        String  carModel= txtCarModel.getText();
        String mileage=txtMileage.getText();
        String engin=txtEngine.getText();
        String bPH=txtbhp.getText();
        String TM=(String)CBox.getSelectedItem();
        String seat=txtSpeed.getText();
        String colour=txtColour.getText();
        String sCharge=txtYSC.getText();
        String cost=txtAvg.getText();
        String Fuel=(String)CBoxFuel.getSelectedItem();
        //Check No Field should be empty
        if(carname.equals("")||carModel.equals("")||engin.equals("")||mileage.equals("")||bPH.equals("")
                ||seat.equals("")||colour.equals("")||sCharge.equals("")||cost.equals("")){
        JOptionPane.showMessageDialog(rootPane, "Fill All The Fields");
        }
        else try{
                Class.forName("java.sql.DriverManager");
                
                Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/cardb","root","yusra12345");
                Statement stmt=(Statement) con.createStatement();
                //Quary fro database
                String sql1="insert into cardetails values('"+carname+"','"+carModel+"','"+mileage+"','"+engin+"','"
                        +bPH+"','"+TM+"','"+seat+"','"+colour+"','"+sCharge+"','"+cost+"','"+Fuel+"');";
                
                stmt.executeUpdate(sql1);
               JOptionPane.showMessageDialog(rootPane,"Details are uploaded successfully");
              //Close Statement
                stmt.close();
                con.close();
                //Clear Field
                Clear();
        }
        catch(Exception e){
            System.out.println(e);
        JOptionPane.showMessageDialog(null,e);
        System.exit(0);
        }
    }//GEN-LAST:event_btnSubActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        Clear();
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
       this.setVisible(false);
        new AdminPortal().setVisible(true);
    }//GEN-LAST:event_btnBackActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void txtCarModelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCarModelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCarModelActionPerformed

    private void txtMileageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMileageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMileageActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(A_ADDcardetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(A_ADDcardetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(A_ADDcardetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(A_ADDcardetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new A_ADDcardetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBox;
    private javax.swing.JComboBox<String> CBoxFuel;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSub;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtAvg;
    private javax.swing.JTextField txtCarModel;
    private javax.swing.JPanel txtCarName;
    private javax.swing.JTextField txtColour;
    private javax.swing.JTextField txtEngine;
    private javax.swing.JTextField txtMileage;
    private javax.swing.JTextField txtSpeed;
    private javax.swing.JTextField txtYSC;
    private javax.swing.JTextField txtbhp;
    // End of variables declaration//GEN-END:variables
}
